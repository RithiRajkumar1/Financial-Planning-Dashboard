# UAT Test Cases
## Project: Financial Planning & Forecasting Dashboard
## UAT Round: Round 1 | Date: April 2025

---

## Test Case Summary

| Total Cases | Passed | Failed | Blocked | Not Run | Pass Rate |
|-------------|--------|--------|---------|---------|-----------|
| 20 | 15 | 3 | 1 | 1 | 75% |

---

## Module 1: Dashboard Load & Access

| TC ID | Test Case | Steps | Expected Result | Actual Result | Status | Tester | Date |
|-------|-----------|-------|----------------|--------------|--------|--------|------|
| TC-001 | Dashboard loads within 5 seconds | 1. Login 2. Navigate to dashboard | Page loads in ≤5 seconds | Loaded in 3.2s | ✅ Pass | Rithi R. | 01-Apr |
| TC-002 | Finance Manager role sees all departments | Login as Finance Manager → Open dashboard | All 4 departments visible | All 4 visible | ✅ Pass | Rithi R. | 01-Apr |
| TC-003 | Dept Head role sees only own department | Login as Dept Head → Open dashboard | Only own dept data visible | Only own dept shown | ✅ Pass | Rithi R. | 01-Apr |
| TC-004 | Unauthorised user cannot access dashboard | Login as non-finance user → Navigate to dashboard URL | Access denied message shown | Access denied shown | ✅ Pass | Rithi R. | 01-Apr |

---

## Module 2: Budget vs Actuals Display

| TC ID | Test Case | Steps | Expected Result | Actual Result | Status | Tester | Date |
|-------|-----------|-------|----------------|--------------|--------|--------|------|
| TC-005 | Correct total budget displayed | Open dashboard → Check header KPI | Total matches approved budget figure | Matches | ✅ Pass | Rithi R. | 02-Apr |
| TC-006 | Correct total actuals displayed | Open dashboard → Check actuals KPI | Total matches ERP actuals | Matches | ✅ Pass | Rithi R. | 02-Apr |
| TC-007 | Variance % calculated correctly | Check variance for Marketing dept | Formula: (Actual-Budget)/Budget×100 | Incorrect — showing absolute value only | ❌ Fail | Rithi R. | 02-Apr |
| TC-008 | Over-budget departments flagged | Check Operations dept (>10% over) | ⚠️ flag visible on Operations row | Flag not appearing | ❌ Fail | Rithi R. | 02-Apr |
| TC-009 | Department filter works correctly | Select "Marketing" from dropdown | Only Marketing data displayed | Works correctly | ✅ Pass | Rithi R. | 02-Apr |

---

## Module 3: Time Period Filtering

| TC ID | Test Case | Steps | Expected Result | Actual Result | Status | Tester | Date |
|-------|-----------|-------|----------------|--------------|--------|--------|------|
| TC-010 | Monthly filter shows correct data | Select Jan 2024 from filter | Jan 2024 data only displayed | Correct | ✅ Pass | Rithi R. | 03-Apr |
| TC-011 | Quarterly filter aggregates correctly | Select Q1 2024 | Jan+Feb+Mar summed correctly | Correct | ✅ Pass | Rithi R. | 03-Apr |
| TC-012 | YTD filter shows cumulative totals | Select YTD | All months from Jan to current summed | Blocked — YTD filter not yet deployed | 🔵 Blocked | Rithi R. | 03-Apr |
| TC-013 | Date range picker allows custom range | Select custom range Mar-Jun 2024 | Data for selected range displayed | Correct | ✅ Pass | Rithi R. | 03-Apr |

---

## Module 4: Trend Chart

| TC ID | Test Case | Steps | Expected Result | Actual Result | Status | Tester | Date |
|-------|-----------|-------|----------------|--------------|--------|--------|------|
| TC-014 | Monthly trend chart displays all months | Open Trend section | 12 months of data plotted | All 12 months visible | ✅ Pass | Rithi R. | 04-Apr |
| TC-015 | Hovering on chart shows data tooltip | Hover over a data point | Tooltip shows month, budget, actual | Tooltip works | ✅ Pass | Rithi R. | 04-Apr |
| TC-016 | Trend chart updates on dept filter change | Select "Finance" filter | Chart updates to Finance data only | Chart not updating dynamically | ❌ Fail | Rithi R. | 04-Apr |

---

## Module 5: Forecast

| TC ID | Test Case | Steps | Expected Result | Actual Result | Status | Tester | Date |
|-------|-----------|-------|----------------|--------------|--------|--------|------|
| TC-017 | Rolling 3-month forecast calculated | Check forecast section | AVG of last 3 months × 3 for quarter | Correct calculation | ✅ Pass | Rithi R. | 04-Apr |
| TC-018 | Forecast displayed as projected line on chart | Open forecast chart | Dashed line showing future projection | Visible and correct | ✅ Pass | Rithi R. | 04-Apr |

---

## Module 6: Export

| TC ID | Test Case | Steps | Expected Result | Actual Result | Status | Tester | Date |
|-------|-----------|-------|----------------|--------------|--------|--------|------|
| TC-019 | Export to Excel downloads correct data | Click Export → Excel | .xlsx file downloaded with correct data | Not yet tested (feature in next build) | ⬜ Not Run | - | - |
| TC-020 | Export to PDF generates formatted report | Click Export → PDF | PDF generated with dashboard layout | Correct format | ✅ Pass | Rithi R. | 04-Apr |

---

## Defect Summary

| Defect ID | TC ID | Description | Severity | Status |
|-----------|-------|-------------|----------|--------|
| DEF-001 | TC-007 | Variance % shows absolute value instead of percentage | 🟠 High | Open |
| DEF-002 | TC-008 | Over-budget flag not triggering for >10% variance | 🟠 High | Open |
| DEF-003 | TC-016 | Trend chart not updating when department filter changes | 🟡 Medium | Open |
