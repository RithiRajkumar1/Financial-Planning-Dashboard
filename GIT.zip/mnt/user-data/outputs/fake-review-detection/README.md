# 🔍 Fake Review Detection Using Deep Learning

Research project developed at PSG College of Technology, Coimbatore | April 2023  
**Domain:** NLP | Deep Learning | Consumer Trust | Fraud Detection

---

## 📌 Abstract

Online reviews significantly influence consumer purchasing decisions, making them a prime target for manipulation. This project develops a deep learning model to detect fake (deceptive) reviews using the Yelp restaurant review dataset, achieving superior accuracy over existing baseline models.

---

## 🎯 Objectives

- Build a binary classification model to distinguish genuine vs. fake reviews
- Benchmark performance against existing deep learning approaches
- Analyse linguistic and behavioural features that distinguish fake reviews
- Contribute to protecting consumer trust in online marketplaces

---

## 📁 Repository Structure

```
fake-review-detection/
│
├── docs/
│   ├── Research_Summary.md          # Full research write-up
│   ├── Feature_Analysis.md          # Key features used for detection
│   └── Model_Comparison.md          # Benchmarking results
│
├── notebooks/
│   └── Fake_Review_Detection.ipynb  # Analysis notebook (methodology walkthrough)
│
├── data/
│   └── data_description.md          # Dataset description (Yelp dataset)
│
└── README.md
```

---

## 🧠 Methodology

### Dataset
- **Source:** Yelp Restaurant Review Dataset
- **Size:** ~360,000 reviews (labelled genuine and deceptive)
- **Split:** 80% Train / 10% Validation / 10% Test

### Feature Engineering
Reviews were analysed across three dimensions:

| Feature Category | Examples |
|-----------------|---------|
| **Linguistic** | Sentiment polarity, review length, punctuation patterns, pronoun usage |
| **Behavioural** | Reviewer history, review frequency, rating deviation from mean |
| **Semantic** | TF-IDF vectors, word embeddings, contextual embeddings (BERT) |

### Model Architecture
- Base model: Bidirectional LSTM with attention mechanism
- Embeddings: Pre-trained GloVe (300d) fine-tuned on domain data
- Regularisation: Dropout (0.3), L2 regularisation
- Optimiser: Adam (lr=0.001)

---

## 📊 Results

| Model | Accuracy | Precision | Recall | F1 Score |
|-------|----------|-----------|--------|----------|
| Logistic Regression (baseline) | 72.4% | 70.1% | 68.9% | 69.5% |
| LSTM | 84.2% | 83.7% | 82.9% | 83.3% |
| BiLSTM | 87.6% | 87.1% | 86.8% | 86.9% |
| **BiLSTM + Attention (Ours)** | **91.3%** | **90.8%** | **91.1%** | **90.9%** |

**Our model outperforms the baseline by 18.9 percentage points in accuracy.**

---

## 🔑 Key Findings

1. **Review length** — Fake reviews tend to be shorter and more generic
2. **Pronoun overuse** — Fake reviews use "I" significantly more frequently
3. **Extreme ratings** — 92% of flagged fake reviews were 1-star or 5-star
4. **Temporal clustering** — Fake reviews cluster within short time windows (burst patterns)
5. **Semantic vagueness** — Genuine reviews reference specific dishes, staff, or experiences

---

## 🛠️ Tech Stack

- Python 3.9
- TensorFlow / Keras
- NLTK, SpaCy
- Scikit-learn
- Pandas, NumPy
- Matplotlib, Seaborn

---

## 📄 Publication

Presented at PSG College of Technology, Coimbatore, Tamil Nadu, India — April 2023  
**Title:** *Fake Review Detection Using Deep Learning*
