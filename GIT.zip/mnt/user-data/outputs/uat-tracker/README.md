# 🧪 UAT Tracking & Defect Management Framework

A structured User Acceptance Testing (UAT) framework for Business Analysts — covering test planning, test case documentation, defect logging, stakeholder sign-off, and go-live readiness tracking.

---

## 🎯 Purpose

This repository provides a reusable UAT framework that Business Analysts can adapt for any software implementation project. It covers the full UAT lifecycle from planning to sign-off.

---

## 📁 Repository Structure

```
uat-tracker/
│
├── templates/
│   ├── UAT_Plan_Template.md              # UAT planning document
│   └── UAT_Sign_Off_Template.md          # Stakeholder sign-off sheet
│
├── test-cases/
│   └── Test_Cases_Financial_Dashboard.md # Sample test cases (Financial Dashboard project)
│
├── defect-log/
│   └── Defect_Log.md                     # Defect tracking register
│
└── README.md
```

---

## 📋 UAT Lifecycle Overview

```
1. UAT PLANNING
   └── Define scope, entry/exit criteria, timeline, resources

2. TEST CASE PREPARATION
   └── Write test cases mapped to business requirements

3. TEST EXECUTION
   └── Testers execute cases, log pass/fail/blocked

4. DEFECT MANAGEMENT
   └── Log defects, assign severity, track to resolution

5. REGRESSION TESTING
   └── Re-test fixed defects, validate no new issues

6. SIGN-OFF
   └── Stakeholders review results and approve go-live
```

---

## 🚦 Defect Severity Guide

| Severity | Definition | SLA for Fix |
|----------|-----------|------------|
| 🔴 Critical | System crash, data loss, core feature broken | Fix before UAT continues |
| 🟠 High | Major feature not working, no workaround | Fix within 24 hours |
| 🟡 Medium | Feature partially working, workaround exists | Fix before go-live |
| 🟢 Low | Minor UI issue, cosmetic defect | Fix in next release |

---

## ✅ UAT Entry & Exit Criteria

### Entry Criteria (Before UAT begins)
- [ ] All functional requirements signed off
- [ ] UAT environment deployed and stable
- [ ] Test data prepared and loaded
- [ ] Test cases reviewed and approved
- [ ] UAT participants identified and available

### Exit Criteria (Before Go-Live)
- [ ] 100% of test cases executed
- [ ] 0 Critical defects open
- [ ] 0 High defects open
- [ ] All Medium defects have approved workarounds or fix dates
- [ ] Stakeholder sign-off obtained
