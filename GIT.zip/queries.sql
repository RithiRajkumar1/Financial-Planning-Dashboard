-- ============================================================
-- 01_budget_vs_actuals.sql
-- Purpose: Core variance analysis - Budget vs Actuals by Department
-- Author: Rithi Rajkumar
-- ============================================================

SELECT
    d.department_name,
    d.cost_center_code,
    f.fiscal_year,
    f.fiscal_month,
    f.fiscal_quarter,

    -- Budget and Actuals
    SUM(f.budget_amount)                                        AS total_budget,
    SUM(f.actual_amount)                                        AS total_actuals,

    -- Variance Calculations
    SUM(f.actual_amount) - SUM(f.budget_amount)                AS variance_absolute,
    ROUND(
        ((SUM(f.actual_amount) - SUM(f.budget_amount)) 
        / NULLIF(SUM(f.budget_amount), 0)) * 100, 2
    )                                                          AS variance_pct,

    -- YTD Actuals
    SUM(SUM(f.actual_amount)) OVER (
        PARTITION BY d.department_name, f.fiscal_year
        ORDER BY f.fiscal_month
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )                                                          AS ytd_actuals,

    -- Variance Flag
    CASE
        WHEN ROUND(
            ((SUM(f.actual_amount) - SUM(f.budget_amount)) 
            / NULLIF(SUM(f.budget_amount), 0)) * 100, 2
        ) < -10 THEN 'OVER BUDGET ⚠️'
        WHEN ROUND(
            ((SUM(f.actual_amount) - SUM(f.budget_amount)) 
            / NULLIF(SUM(f.budget_amount), 0)) * 100, 2
        ) > 10  THEN 'UNDER SPEND'
        ELSE 'ON TRACK ✅'
    END                                                        AS budget_status

FROM financial_data f
JOIN departments d ON f.department_id = d.department_id

WHERE f.fiscal_year = YEAR(CURRENT_DATE)

GROUP BY
    d.department_name,
    d.cost_center_code,
    f.fiscal_year,
    f.fiscal_month,
    f.fiscal_quarter

ORDER BY
    f.fiscal_year,
    f.fiscal_month,
    d.department_name;


-- ============================================================
-- 02_monthly_trend.sql
-- Purpose: Month-over-month spend trend per department
-- ============================================================

SELECT
    d.department_name,
    f.fiscal_year,
    f.fiscal_month,

    SUM(f.actual_amount)                                        AS monthly_actuals,

    -- Previous Month Actuals
    LAG(SUM(f.actual_amount), 1) OVER (
        PARTITION BY d.department_name
        ORDER BY f.fiscal_year, f.fiscal_month
    )                                                          AS prev_month_actuals,

    -- Month-over-Month Change
    SUM(f.actual_amount) - LAG(SUM(f.actual_amount), 1) OVER (
        PARTITION BY d.department_name
        ORDER BY f.fiscal_year, f.fiscal_month
    )                                                          AS mom_change,

    -- MoM % Change
    ROUND(
        ((SUM(f.actual_amount) - LAG(SUM(f.actual_amount), 1) OVER (
            PARTITION BY d.department_name
            ORDER BY f.fiscal_year, f.fiscal_month
        )) / NULLIF(LAG(SUM(f.actual_amount), 1) OVER (
            PARTITION BY d.department_name
            ORDER BY f.fiscal_year, f.fiscal_month
        ), 0)) * 100, 2
    )                                                          AS mom_change_pct

FROM financial_data f
JOIN departments d ON f.department_id = d.department_id

GROUP BY
    d.department_name,
    f.fiscal_year,
    f.fiscal_month

ORDER BY
    d.department_name,
    f.fiscal_year,
    f.fiscal_month;


-- ============================================================
-- 03_forecast_model.sql
-- Purpose: Rolling 3-month average forecast
-- ============================================================

WITH monthly_spend AS (
    SELECT
        department_id,
        fiscal_year,
        fiscal_month,
        SUM(actual_amount) AS monthly_actuals
    FROM financial_data
    GROUP BY department_id, fiscal_year, fiscal_month
),
rolling_avg AS (
    SELECT
        department_id,
        fiscal_year,
        fiscal_month,
        monthly_actuals,
        ROUND(
            AVG(monthly_actuals) OVER (
                PARTITION BY department_id
                ORDER BY fiscal_year, fiscal_month
                ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
            ), 2
        ) AS rolling_3m_forecast
    FROM monthly_spend
)
SELECT
    d.department_name,
    r.fiscal_year,
    r.fiscal_month,
    r.monthly_actuals,
    r.rolling_3m_forecast,
    ROUND(r.rolling_3m_forecast * 3, 2) AS quarterly_forecast_estimate
FROM rolling_avg r
JOIN departments d ON r.department_id = d.department_id
ORDER BY d.department_name, r.fiscal_year, r.fiscal_month;
