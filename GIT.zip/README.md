# 📊 Financial Planning & Forecasting Dashboard

A structured Business Analysis project demonstrating end-to-end financial planning, budgeting, variance tracking, and forecasting using SQL and Excel-based frameworks.

---

## 🎯 Project Objective

Design and document a data-driven financial planning solution that enables finance and operations teams to:
- Track **actuals vs. budget** across departments
- Monitor **variance trends** month-over-month
- Forecast **quarterly and annual spend** using historical patterns
- Support **decision-making** through KPI dashboards

---

## 📁 Repository Structure

```
financial-planning-dashboard/
│
├── docs/
│   ├── BRD_Financial_Planning.md        # Business Requirements Document
│   ├── FRD_Financial_Planning.md        # Functional Requirements Document
│   └── Dashboard_Wireframe.md           # Dashboard layout and KPI definitions
│
├── sql/
│   ├── 01_budget_vs_actuals.sql         # Core variance analysis query
│   ├── 02_monthly_trend.sql             # Month-over-month trend tracking
│   └── 03_forecast_model.sql            # Rolling forecast logic
│
├── data/
│   └── sample_financial_data.csv        # Sample dataset for testing queries
│
└── README.md
```

---

## 📋 Business Requirements Summary

| # | Requirement | Priority |
|---|-------------|----------|
| BR-01 | System shall display actual vs. budgeted spend by department | High |
| BR-02 | System shall calculate variance in absolute and percentage terms | High |
| BR-03 | System shall support monthly and quarterly aggregation | High |
| BR-04 | System shall enable drill-down by cost center | Medium |
| BR-05 | System shall provide rolling 3-month forecast | Medium |
| BR-06 | System shall flag departments exceeding 10% negative variance | High