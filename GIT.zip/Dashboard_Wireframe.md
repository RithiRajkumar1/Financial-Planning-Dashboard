# Dashboard Wireframe & KPI Definitions
## Financial Planning & Forecasting Dashboard

---

## Dashboard Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  FINANCIAL PLANNING DASHBOARD          FY2024 | Filter: All Depts│
├───────────────┬───────────────┬───────────────┬─────────────────┤
│  TOTAL BUDGET │ TOTAL ACTUALS │   VARIANCE    │  BUDGET STATUS  │
│  £2,450,000   │  £2,389,200   │  -£60,800     │   ✅ ON TRACK   │
│               │               │   (-2.48%)    │                 │
├───────────────┴───────────────┴───────────────┴─────────────────┤
│                                                                   │
│  Budget vs Actuals by Department (Bar Chart)                      │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │ Marketing   ████████████░░░  Budget: £255K | Actual: £248K  │ │
│  │ Operations  ████████████████ Budget: £410K | Actual: £452K⚠️│ │
│  │ Finance     ████████████░░░  Budget: £200K | Actual: £189K  │ │
│  │ HR          █████████████░░  Budget: £188K | Actual: £181K  │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                   │
├───────────────────────────────┬───────────────────────────────── ┤
│  Monthly Spend Trend          │  Rolling 3M Forecast              │
│  (Line Chart)                 │  (Projection Chart)               │
│  Jan Feb Mar Apr May Jun...   │  Forecast vs Actuals              │
│                               │                                   │
├───────────────────────────────┴───────────────────────────────── ┤
│  Department Detail Table                                          │
│  Dept | Cost Center | Budget | Actual | Variance | Status        │
│  ─────────────────────────────────────────────────────────────── │
│  Ops  | CC-OPS-01   | £80K   | £91.2K | +£11.2K  | ⚠️ OVER     │
│  Mktg | CC-MKT-01   | £50K   | £47.8K | -£2.2K   | ✅ OK       │
└─────────────────────────────────────────────────────────────────┘
```

---

## KPI Definitions

| KPI | Definition | Formula | Target |
|-----|-----------|---------|--------|
| Total Budget | Approved annual budget for period | SUM(budget_amount) | Set annually |
| Total Actuals | Actual spend for period | SUM(actual_amount) | ≤ Budget |
| Variance (£) | Difference between actuals and budget | Actuals - Budget | < 0 (under budget) |
| Variance (%) | Percentage deviation from budget | (Variance / Budget) × 100 | Within ±10% |
| YTD Spend | Cumulative actuals from start of fiscal year | Running SUM(actuals) | ≤ YTD Budget |
| Rolling Forecast | Projected spend based on 3-month average | AVG(last 3 months actuals) | ≤ Budget |
| Budget Status | Health flag based on variance % | See logic below | ON TRACK |

### Budget Status Logic
- 🔴 **OVER BUDGET**: Variance % < -10%
- 🟡 **AT RISK**: Variance % between -5% and -10%
- 🟢 **ON TRACK**: Variance % within ±5%
- 🔵 **UNDER SPEND**: Variance % > +10%

---

## User Stories

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-01 | Finance Manager | View total budget vs actuals at a glance | I can assess overall financial health quickly |
| US-02 | Department Head | Filter dashboard by my department | I only see data relevant to me |
| US-03 | CFO | See departments flagged as over budget | I can intervene before quarter-end |
| US-04 | Finance Manager | View month-over-month spend trend | I can identify seasonal patterns |
| US-05 | Finance Manager | Export the report to Excel | I can share with stakeholders offline |
| US-06 | Finance Analyst | Drill down by cost center | I can pinpoint the exact source of variance |
