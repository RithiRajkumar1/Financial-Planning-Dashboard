# Order Fulfilment Process Flows
## As-Is (Current State) vs To-Be (Future State)

---

## AS-IS PROCESS — Current Order Fulfilment Flow

```
CUSTOMER          SALES TEAM         WAREHOUSE          LOGISTICS
   │                  │                  │                  │
   │──── Email ───────>│                  │                  │
   │    with order     │                  │                  │
   │                   │ Manual key-in    │                  │
   │                   │ into ERP system  │                  │
   │                   │ (error-prone)    │                  │
   │                   │                  │                  │
   │                   │ Print pick list  │                  │
   │                   │─────────────────>│                  │
   │                   │                  │                  │
   │                   │                  │ Manual search    │
   │                   │                  │ for items in     │
   │                   │                  │ warehouse        │
   │                   │                  │                  │
   │                   │                  │ Paper-based pack │
   │                   │                  │ & label          │
   │                   │                  │                  │
   │                   │                  │ Call courier ───>│
   │                   │                  │                  │ Manual booking
   │                   │                  │                  │
   │<── Email ─────────────────────────────────────────────── │
   │   (dispatch       │                  │                  │
   │    confirmation)  │                  │                  │
```

**Pain Points Highlighted:**
- ❌ No structured order intake — relies on email
- ❌ Manual ERP data entry — 8% error rate
- ❌ Paper pick lists — lost, misread, slow
- ❌ Manual courier booking — 2hrs/day wasted
- ❌ No order tracking for customer
- ❌ Stock levels update only at end of day

**Average End-to-End Time: 3.2 days**

---

## TO-BE PROCESS — Future State Order Fulfilment Flow

```
CUSTOMER          ORDER SYSTEM       WAREHOUSE SYSTEM   LOGISTICS API
   │                  │                  │                  │
   │── Web Form ──────>│                  │                  │
   │   (structured)    │                  │                  │
   │                   │ Auto-validate    │                  │
   │                   │ & create order   │                  │
   │<── Auto confirm ──│                  │                  │
   │   email sent      │                  │                  │
   │                   │ Real-time stock  │                  │
   │                   │ check via API ───>│                  │
   │                   │                  │ Digital pick     │
   │                   │                  │ list sent to     │
   │                   │                  │ scanner device   │
   │                   │                  │                  │
   │                   │                  │ Scan-verify      │
   │                   │                  │ items → pack     │
   │                   │                  │                  │
   │                   │                  │ Auto-dispatch ───>│
   │                   │                  │                  │ API books
   │                   │                  │                  │ best carrier
   │<── Tracking ──────────────────────────────────────────── │
   │   link sent       │                  │                  │
   │                   │                  │                  │
   │ Self-service      │                  │                  │
   │ tracking portal   │                  │                  │
```

**Improvements Delivered:**
- ✅ Structured web form — zero manual keying
- ✅ Auto order confirmation — instant
- ✅ Real-time stock sync — no overselling
- ✅ Digital pick lists with scan verification — <1% error rate
- ✅ Automated courier API — 15 mins/day effort
- ✅ Customer self-service tracking portal

**Target End-to-End Time: 1 day**

---

## Process Metrics Comparison

| Step | As-Is Time | To-Be Time | Saving |
|------|-----------|-----------|--------|
| Order intake | 30 mins | 2 mins | 28 mins |
| ERP entry | 20 mins | 0 mins (automated) | 20 mins |
| Warehouse pick | 45 mins | 20 mins | 25 mins |
| Packing & labelling | 15 mins | 10 mins | 5 mins |
| Courier booking | 120 mins/day | 15 mins/day | 105 mins/day |
| **Total per order** | **~2 hrs** | **~32 mins** | **~73% faster** |
