# Business Requirements Document (BRD)
## Financial Planning & Forecasting Dashboard

**Document Version:** 1.0  
**Author:** Rithi Rajkumar  
**Date:** April 2025  
**Status:** Approved  

---

## 1. Executive Summary

The Finance team currently relies on manual Excel consolidations to track budget vs. actuals, resulting in delayed reporting, inconsistent data, and limited visibility into departmental spend. This project aims to deliver a centralized financial planning dashboard that automates variance tracking, supports forecasting, and enables data-driven decisions.

---

## 2. Business Objectives

- Reduce monthly financial reporting cycle from 5 days to 1 day
- Provide real-time visibility into budget consumption across departments
- Enable proactive identification of cost overruns before quarter-end
- Standardize financial KPIs across business units

---

## 3. Stakeholders

| Stakeholder | Role | Interest |
|-------------|------|----------|
| CFO | Executive Sponsor | Strategic financial oversight |
| Finance Manager | Primary User | Monthly reporting & forecasting |
| Department Heads | Secondary Users | Own department spend tracking |
| IT / Data Team | Technical Owner | Data pipeline & system integration |
| Business Analyst | Requirements Owner | Bridging business & technical needs |

---

## 4. Scope

### In Scope
- Budget vs. actuals tracking at department and cost-center level
- Variance calculation (absolute and percentage)
- Monthly, quarterly, and annual aggregation
- Rolling 3-month forecast based on historical spend
- Automated alerts for variance thresholds exceeding ±10%

### Out of Scope
- Integration with ERP systems (Phase 2)
- Headcount and HR cost tracking
- Multi-currency support

---

## 5. Business Requirements

| ID | Requirement | Priority | Source |
|----|-------------|----------|--------|
| BR-01 | The system shall display actual vs. budgeted spend by department | Must Have | CFO |
| BR-02 | The system shall calculate variance in absolute (£) and percentage (%) terms | Must Have | Finance Manager |
| BR-03 | The system shall support monthly and quarterly time aggregations | Must Have | Finance Manager |
| BR-04 | The system shall allow drill-down by cost center within each department | Should Have | Department Heads |
| BR-05 | The system shall generate a rolling 3-month expenditure forecast | Should Have | CFO |
| BR-06 | The system shall flag any department exceeding 10% negative variance | Must Have | CFO |
| BR-07 | The system shall export reports to Excel and PDF formats | Should Have | Finance Manager |
| BR-08 | The system shall display YTD (Year-to-Date) cumulative spend | Must Have | Finance Manager |

---

## 6. Assumptions

- Source data will be provided from the existing ERP export in CSV format
- Finance team will validate data before dashboard publication
- Initial deployment targets internal Finance and Executive users only

---

## 7. Constraints

- Dashboard must be accessible via web browser with no desktop installation
- Data refresh to occur daily at 6:00 AM
- Historical data available from FY2022 onwards

---

## 8. Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Data quality issues from ERP exports | Medium | High | Data validation layer before ingestion |
| Stakeholder misalignment on KPI definitions | High | Medium | Requirement workshops with sign-off |
| Delayed IT resources for pipeline setup | Medium | High | Early IT engagement and phased delivery |

---

## 9. Success Criteria

- Finance team can generate monthly variance report in under 10 minutes
- Dashboard adopted by 100% of department heads within 30 days of go-live
- Zero manual Excel consolidations required post-implementation
- Forecast accuracy within ±5% of actuals for rolling 3-month window
