# Gap Analysis Report
## Retail Order Fulfilment & Inventory Management

**Document Version:** 1.0  
**Author:** Rithi Rajkumar  
**Date:** March 2025  
**Status:** Final  

---

## 1. Executive Summary

This gap analysis identifies the delta between the current (As-Is) retail operations process and the desired future state (To-Be). Analysis was conducted through process observation, stakeholder interviews, and data review across Order Management, Inventory, Warehouse, and Logistics functions.

**Overall Maturity Score:**
| Dimension | Current Score | Target Score | Gap |
|-----------|-------------|-------------|-----|
| Process Automation | 2/5 | 4/5 | -2 |
| Data Accuracy | 2.5/5 | 4.5/5 | -2 |
| Visibility & Reporting | 1.5/5 | 4/5 | -2.5 |
| Customer Experience | 2/5 | 4/5 | -2 |

---

## 2. Gap Analysis by Process Area

### 2.1 Order Management

| Gap ID | As-Is | To-Be | Gap Description | Priority |
|--------|-------|-------|----------------|----------|
| G-01 | Orders received via email manually keyed into system | Orders submitted via structured web form auto-ingested | No structured intake — high re-keying effort and errors | High |
| G-02 | No order confirmation sent to customer automatically | Auto-confirmation email triggered on order creation | Customer has no proof of order until manual follow-up | High |
| G-03 | Order status only visible to internal team | Customer self-service tracking portal available | Customer service fielding 40+ status calls/day unnecessarily | Medium |

### 2.2 Inventory Management

| Gap ID | As-Is | To-Be | Gap Description | Priority |
|--------|-------|-------|----------------|----------|
| G-04 | Stock levels updated in ERP once daily (batch) | Real-time ERP stock updates on every transaction | 12% discrepancy leads to overselling and stockouts | High |
| G-05 | No low-stock alerts configured | Automated reorder alerts at configurable threshold | Stockouts discovered reactively — too late for action | High |
| G-06 | Physical count done monthly | Cycle counting with barcode scanners weekly | Discrepancies accumulate over 30-day cycle | Medium |

### 2.3 Warehouse Operations

| Gap ID | As-Is | To-Be | Gap Description | Priority |
|--------|-------|-------|----------------|----------|
| G-07 | Paper-based pick lists printed and distributed manually | Digital pick lists on handheld scanners | 8% pick error rate; physical lists lost or misread | High |
| G-08 | No scan verification at pack station | Barcode scan confirmation before sealing package | Wrong items shipped — returns increase by ~15% | High |
| G-09 | Packing materials selected manually | System-suggested packaging based on order dimensions | Excess packaging costs ~£0.45/order | Low |

### 2.4 Logistics & Dispatch

| Gap ID | As-Is | To-Be | Gap Description | Priority |
|--------|-------|-------|----------------|----------|
| G-10 | Courier booking done manually via phone/portal | Automated dispatch via courier API | 2 hours/day spent on manual booking | High |
| G-11 | No carrier rate comparison | Automated carrier selection based on cost & SLA | Suboptimal carrier chosen regularly | Medium |
| G-12 | No proof-of-delivery tracking | POD automatically captured and stored | Disputes with no evidence resolution | Medium |

### 2.5 Returns Management

| Gap ID | As-Is | To-Be | Gap Description | Priority |
|--------|-------|-------|----------------|----------|
| G-13 | No formal returns process — handled ad hoc | Structured returns portal with reason codes | Inconsistent customer experience, no returns data | High |
| G-14 | Returned stock not re-assessed for resale | Automated quality check workflow for returned items | Good stock written off unnecessarily | Medium |

---

## 3. Root Cause Analysis

### Primary Root Causes Identified:

**1. Lack of system integration**
- ERP, Warehouse, and Logistics systems operate in silos
- No APIs connecting order management to warehouse or courier systems

**2. Manual, paper-based processes**
- Critical operational steps rely on paper (pick lists, order logs)
- Human error rates significantly higher than digital alternatives

**3. Absence of real-time data**
- Batch processing delays create blind spots
- Decisions made on stale data

**4. No defined process ownership**
- Returns and exceptions handled inconsistently across staff
- No SOPs documented or enforced

---

## 4. Recommendations & Prioritisation

### MoSCoW Prioritisation

**Must Have (implement within 3 months)**
- G-01: Structured order intake form
- G-04: Real-time ERP stock updates
- G-07: Digital pick lists with scanners
- G-08: Scan verification at pack station
- G-10: Automated courier API dispatch
- G-13: Formal returns portal

**Should Have (implement within 6 months)**
- G-02: Automated order confirmation
- G-05: Low-stock automated alerts
- G-06: Weekly cycle counting
- G-11: Carrier rate comparison engine
- G-14: Returns quality workflow

**Could Have (implement within 12 months)**
- G-03: Customer self-service tracking
- G-12: POD tracking integration
- G-09: System-suggested packaging

---

## 5. Expected Benefits Summary

| Metric | Current | Target | Improvement |
|--------|---------|--------|-------------|
| Order processing time | 3.2 days | 1 day | 69% reduction |
| Inventory discrepancy | 12% | <2% | 83% reduction |
| Pick error rate | 8% | <1% | 87% reduction |
| Manual effort (dispatch) | 2 hrs/day | 15 mins/day | 87% reduction |
| Returns handling time | 5 days | 1 day | 80% reduction |
| Customer service calls (status) | 40/day | <5/day | 87% reduction |
