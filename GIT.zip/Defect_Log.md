# Defect Log Register
## Project: Financial Planning & Forecasting Dashboard
## UAT Round 1 | Updated: April 2025

---

## Defect Summary Dashboard

| Severity | Open | In Progress | Fixed | Closed |
|----------|------|-------------|-------|--------|
| 🔴 Critical | 0 | 0 | 0 | 0 |
| 🟠 High | 2 | 0 | 0 | 0 |
| 🟡 Medium | 1 | 0 | 0 | 0 |
| 🟢 Low | 0 | 0 | 0 | 0 |
| **Total** | **3** | **0** | **0** | **0** |

---

## Defect Register

| DEF ID | Title | Severity | Module | Steps to Reproduce | Expected | Actual | Reporter | Date Raised | Assigned To | Status | Resolution Date |
|--------|-------|----------|--------|-------------------|----------|--------|----------|-------------|-------------|--------|----------------|
| DEF-001 | Variance % showing absolute value | 🟠 High | Budget vs Actuals | 1. Open dashboard 2. View Marketing dept row 3. Check Variance % column | Variance shown as percentage e.g. -4.4% | Variance showing absolute value e.g. -£2,200 | Rithi R. | 02-Apr-2025 | Dev Team | 🔴 Open | - |
| DEF-002 | Over-budget flag not triggering | 🟠 High | Budget vs Actuals | 1. Open dashboard 2. View Operations row (>10% over budget) 3. Check status flag | ⚠️ Over Budget flag visible | No flag displayed — showing blank | Rithi R. | 02-Apr-2025 | Dev Team | 🔴 Open | - |
| DEF-003 | Trend chart not updating on filter change | 🟡 Medium | Trend Chart | 1. Open dashboard 2. Select "Finance" from dept filter 3. Observe trend chart | Chart updates to show Finance data only | Chart still shows all departments | Rithi R. | 04-Apr-2025 | Dev Team | 🔴 Open | - |

---

## Defect Detail Cards

---

### DEF-001 — Variance % Showing Absolute Value

**Severity:** 🟠 High  
**Status:** Open  
**Module:** Budget vs Actuals  
**Raised by:** Rithi Rajkumar | 02-Apr-2025  

**Description:**  
The Variance column in the department detail table is displaying the variance as an absolute currency value (e.g. -£2,200) instead of a percentage (e.g. -4.4%). This contradicts BR-02 which specifies variance must be shown in both absolute (£) and percentage (%) terms.

**Steps to Reproduce:**  
1. Login as Finance Manager  
2. Navigate to the Financial Dashboard  
3. Scroll to Department Detail Table  
4. Observe the "Variance %" column  

**Expected Result:** -4.40% (percentage format)  
**Actual Result:** -£2,200 (currency format)  

**Business Impact:** Finance team cannot assess proportional variance across departments of different budget sizes. A £5K overspend means very different things in a £50K vs £500K budget.

**Root Cause (Dev Notes):** TBD  
**Fix Required:** Apply percentage formula `(actual-budget)/budget*100` and format as % in Variance % column  

---

### DEF-002 — Over-Budget Flag Not Triggering

**Severity:** 🟠 High  
**Status:** Open  
**Module:** Budget vs Actuals  
**Raised by:** Rithi Rajkumar | 02-Apr-2025  

**Description:**  
The ⚠️ flag for departments exceeding 10% negative variance is not appearing even when Operations dept is 13.7% over budget. This contradicts BR-06.

**Steps to Reproduce:**  
1. Login as Finance Manager  
2. Navigate to Financial Dashboard  
3. Observe Operations department row (Actual: £91,200 vs Budget: £80,000)  
4. Check the Status column  

**Expected Result:** ⚠️ OVER BUDGET flag  
**Actual Result:** Status column blank  

**Business Impact:** CFO cannot identify overspending departments without manually calculating variance. Defeats the purpose of the alerting requirement.

**Root Cause (Dev Notes):** TBD  
**Fix Required:** Implement conditional logic — if variance% < -10, display OVER BUDGET flag  

---

### DEF-003 — Trend Chart Not Updating on Filter Change

**Severity:** 🟡 Medium  
**Status:** Open  
**Module:** Monthly Trend Chart  
**Raised by:** Rithi Rajkumar | 04-Apr-2025  

**Description:**  
When the Department filter is changed (e.g. selecting "Finance"), the department detail table updates correctly but the Monthly Trend Chart continues to display data for all departments instead of filtering.

**Steps to Reproduce:**  
1. Login as Finance Manager  
2. Navigate to Financial Dashboard  
3. Select "Finance" from the Department dropdown filter  
4. Observe Department Detail Table (updates correctly)  
5. Observe Monthly Trend Chart (does not update)  

**Expected Result:** Trend chart shows only Finance department spend trend  
**Actual Result:** Trend chart shows all department data  

**Business Impact:** Medium — workaround is to navigate to Finance-specific report. Core functionality affected but business can proceed with workaround.  

**Workaround:** Use the individual department report page until fix deployed  
**Fix Required:** Trend chart must subscribe to the same filter context as the rest of the dashboard  
